typedef enum _dbgCode{
    enter_task_0E,
    enter_while_1E,
    send2_queue_BE,
    rec_queue_CE,
    send_success_BA,
    send_fail_BF,
    rec_success_CA,
    rec_fail_CF,
    enter_ISR_2E,
    exit_ISR_pass_DA,
    exit_ISR_fail_DF,
    FAIL_FF           
} dbgCode;

void dbgOutputVal(unsigned char outVal);
void dbgOutputLoc(dbgCode c);