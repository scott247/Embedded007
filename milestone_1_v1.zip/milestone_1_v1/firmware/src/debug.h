void dbgOutputVal(unsigned char outVal);
void dbgOutputLoc(unsigned char outVal);