//sends current count value to message queue
int appSendCount(unsigned int* count);
int SendIRval(unsigned int* val);
int ADCavg(void);